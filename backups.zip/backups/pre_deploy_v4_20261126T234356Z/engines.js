/* ============================================================
   GLOBAL PILGRIM — ENGINES
   Live feed, 5-second direction robot, mining accrual,
   settlement processor, surveillance radar and clock.
   ============================================================ */
'use strict';

let ENGINES = [];
let radarZoom = 4.2;
let radarRAF = null;

const CITIES = [
  { n: 'Lagos', lat: 6.52, lon: 3.37 }, { n: 'Abuja', lat: 9.06, lon: 7.49 },
  { n: 'London', lat: 51.5, lon: -0.12 }, { n: 'Dubai', lat: 25.2, lon: 55.27 },
  { n: 'New York', lat: 40.71, lon: -74.0 }, { n: 'Singapore', lat: 1.35, lon: 103.82 },
  { n: 'Hong Kong', lat: 22.32, lon: 114.17 }, { n: 'Tokyo', lat: 35.68, lon: 139.69 },
  { n: 'Frankfurt', lat: 50.11, lon: 8.68 }, { n: 'Johannesburg', lat: -26.2, lon: 28.05 },
  { n: 'Sao Paulo', lat: -23.55, lon: -46.63 }, { n: 'Sydney', lat: -33.87, lon: 151.21 }
];

/* ---------------- lifecycle ---------------- */
function startEngines() {
  stopEngines();
  initMarkets();
  updateClock(); updateTicker();
  ENGINES.push(setInterval(updateClock, 1000));
  ENGINES.push(setInterval(updateTicker, 4000));
  ENGINES.push(setInterval(tickPrices, 1000));
  ENGINES.push(setInterval(robotCycle, 5000));
  ENGINES.push(setInterval(miningTick, 1000));
  ENGINES.push(setInterval(surveillanceTick, 12000));
  ENGINES.push(setInterval(refreshTradingOnly, 2000));
  drawRadar();
  const p = document.getElementById('enginePill');
  if (p) p.innerHTML = '<i class="dot"></i> Engine Live';
  logLine('ovLog', 'Execution engines armed at ' + (session ? session.node : 'HQ') + '.', 'ok');
  logLine('tradeLog', 'Robot standby. Feed streaming ' + MARKETS.length + ' instruments.', 'ok');
  logLine('mineLog', 'Mining core initialised. ' + S.mining.coins.filter(c => c.on).length + ' pools ready.', 'ok');
  logLine('survLog', 'Surveillance armed. Camera mesh ' + S.cameras.length + ' nodes.', 'ok');
}

function stopEngines() {
  ENGINES.forEach(clearInterval);
  ENGINES = [];
  if (radarRAF) { cancelAnimationFrame(radarRAF); radarRAF = null; }
}

/* ---------------- clock & ticker ---------------- */
function updateClock() {
  const d = new Date();
  const t = document.getElementById('clockTime');
  const dd = document.getElementById('clockDate');
  if (t) t.textContent = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  if (dd) dd.textContent = d.toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }) + ' · UTC' + (d.getTimezoneOffset() > 0 ? '-' : '+') + Math.abs(d.getTimezoneOffset() / 60);
  const su = document.getElementById('statUptime');
  if (su) su.textContent = '99.99%';
}

function updateTicker() {
  const el = document.getElementById('ticker');
  if (!el) return;
  el.innerHTML = MARKETS.map(m => {
    const up = m.chg24 >= 0;
    return `<span class="tick">${esc(m.sym)} <b>${fmtPx(m)}</b> <em class="${up ? 'up' : 'down'}">${up ? '+' : ''}${m.chg24.toFixed(2)}%</em></span>`;
  }).join('');
}

/* ---------------- market feed ---------------- */
function initMarkets() {
  MARKETS.forEach(m => {
    if (m.last == null) m.last = m.price;
    if (!m.hist) m.hist = [];
  });
}

function tickPrices() {
  MARKETS.forEach(m => {
    const vol = m.cls === 'Forex' ? 0.0004 : m.cls === 'Metals' ? 0.0012 : m.cls === 'Minerals' ? 0.0015 : m.cls === 'Equity' ? 0.0018 : 0.0035;
    const drift = (Math.random() - 0.5) * vol;
    m.last = m.price;
    m.price = Math.max(0.0001, m.price * (1 + drift));
    m.chg24 = r2(m.chg24 + drift * 100 * 0.4);
    m.hist.push({ t: Date.now(), p: m.price });
    if (m.hist.length > 40) m.hist.shift();

    /* 5-second candlesticks for the terminal chart */
    if (!m.candles) m.candles = [];
    const bucket = Math.floor(Date.now() / 5000) * 5000;
    const lastC = m.candles[m.candles.length - 1];
    if (!lastC || lastC.t !== bucket) {
      m.candles.push({ t: bucket, o: m.price, h: m.price, l: m.price, c: m.price });
      if (m.candles.length > 90) m.candles.shift();
    } else {
      lastC.c = m.price;
      if (m.price > lastC.h) lastC.h = m.price;
      if (m.price < lastC.l) lastC.l = m.price;
    }
  });
  S.positions.filter(p => p.open).forEach(p => {
    const m = MARKETS.find(x => x.sym === p.sym);
    if (m) p.now = m.price;
  });
  const fh = document.getElementById('feedHint');
  if (fh) fh.textContent = 'live · ' + shortTime(new Date());
}

function refreshTradingOnly() {
  if (document.getElementById('view-trading').classList.contains('on')) renderTrading();
  if (document.getElementById('view-terminal').classList.contains('on')) renderTerminal();
  if (document.getElementById('view-overview').classList.contains('on')) {
    set('mTrading', money(S.wallets.trading) + ' <small>USD</small>', true);
    set('mProfit', money(S.wallets.profit) + ' <small>USD</small>', true);
    set('mEquity', money(totalEquity()) + ' <small>USD</small>', true);
  }
}

function refreshPrices() {
  tickPrices();
  renderTrading(); renderOverview(); updateTicker();
  toast('Feed synchronised across ' + MARKETS.length + ' instruments.', 'ok');
}

/* ---------------- trading robot ---------------- */
function toggleRobot() {
  if (ro()) return;
  S.robot.on = !S.robot.on;
  if (S.robot.on) {
    S.robot.startedAt = nowISO();
  } else {
    /* an operator stop must also pause the supervisor, otherwise it would
       restart trading on the very next cycle against the operator's wish */
    S.robot.auto = false;
  }
  audit('ROBOT', 'Autonomous execution ' + (S.robot.on ? 'ACTIVATED' : 'DEACTIVATED'));
  save(); renderTrading(); renderOverview();
  logLine('tradeLog', 'Robot ' + (S.robot.on ? 'ACTIVATED — following 5s direction on all markets.' : 'DEACTIVATED — manual control only. Supervisor paused.'), S.robot.on ? 'ok' : 'warn');
  toast('Trading robot ' + (S.robot.on ? 'activated' : 'deactivated') + '.', S.robot.on ? 'ok' : '');
}

function toggleRobotAuto() {
  if (ro()) return;
  S.robot.auto = !S.robot.auto;
  audit('ROBOT_SUPERVISOR', 'Human-sense supervisor ' + (S.robot.auto ? 'ENABLED' : 'DISABLED'));
  save(); renderTrading(); renderOverview();
  logLine('tradeLog', 'SENSE ' + (S.robot.auto
    ? 'ENABLED — monitoring balances, deploying idle capital and starting trades without a human directive.'
    : 'DISABLED — awaiting human directive.'), S.robot.auto ? 'ok' : 'warn');
  toast('Human-sense supervisor ' + (S.robot.auto ? 'enabled.' : 'disabled.'), S.robot.auto ? 'ok' : '');
}

function toggleAutoInvest() {
  if (ro()) return;
  S.robot.autoInvest = !S.robot.autoInvest;
  audit('ROBOT_AUTOINVEST', 'Autonomous reinvestment ' + (S.robot.autoInvest ? 'ENABLED' : 'DISABLED'));
  save(); renderTrading();
  toast('Autonomous reinvestment ' + (S.robot.autoInvest ? 'enabled.' : 'disabled.'), S.robot.autoInvest ? 'ok' : '');
}

function toggleAutoSweep() {
  if (ro()) return;
  S.robot.autoSweep = !S.robot.autoSweep;
  audit('ROBOT_AUTOSWEEP', 'Automatic profit sweep ' + (S.robot.autoSweep ? 'ENABLED' : 'DISABLED'));
  save(); renderTrading();
  toast('Automatic profit sweep ' + (S.robot.autoSweep ? 'enabled — profit lands in Profit Balance then moves to Main instantly.' : 'disabled — profit stays ring-fenced in Profit Balance.'), S.robot.autoSweep ? 'ok' : '');
}

/* Sweep the whole Profit Balance to Main. Used by the supervisor the instant a
   position closes in profit, and by the manual "Profit -> Main" control. */
function sweepProfit(auto) {
  const bal = r2(S.wallets.profit || 0);
  if (!(bal > 0)) return 0;
  post({ type: 'AUTO_SWEEP', from: 'profit', to: 'main', amount: bal, note: (auto ? 'Autonomous profit sweep' : 'Profit sweep') + ' — realised profit routed to Main Balance' });
  audit('AUTO_SWEEP', usd(bal) + ' Profit → Main' + (auto ? ' (autonomous)' : ''));
  logLine('tradeLog', 'SENSE — ' + usd(bal) + ' realised profit swept to Main Balance' + (auto ? ' automatically.' : '.'), 'ok');
  return bal;
}

function robotCycle() {
  if (!session) return;
  const lot = Math.max(1, Number(S.settings.lot) || 250);
  const tp = Math.max(0.05, Number(S.settings.tp) || 1.2);
  const win = Math.max(2, Number(S.settings.dirWindow) || 6) * 1000;

  /* ---- human-sense supervisor: acts with no human directive ---- */
  if (S.robot.auto) {
    if (!S.robot.on && S.wallets.trading > 0) {
      S.robot.on = true;
      S.robot.startedAt = nowISO();
      audit('ROBOT_AUTO_START', 'Trading commenced automatically · trading balance ' + usd(S.wallets.trading));
      logLine('tradeLog', 'SENSE — capital detected (' + usd(S.wallets.trading) + '). Trading started automatically.', 'ok');
      toast('Human-sense robot started trading automatically.', 'ok');
    }
    if (S.robot.autoInvest && S.wallets.main > 0 && S.wallets.trading < lot) {
      const target = lot * 2;
      const amt = r2(Math.min(S.wallets.main, Math.max(0, target - S.wallets.trading)));
      if (amt > 0.01) {
        post({ type: 'AUTO_INVEST', from: 'main', to: 'trading', amount: amt, note: 'Autonomous reinvestment — supervisor deployed idle Main Balance' });
        audit('AUTO_INVEST', usd(amt) + ' Main → Trading (autonomous)');
        logLine('tradeLog', 'SENSE — deployed ' + usd(amt) + ' from Main Balance to keep capital working.', 'ok');
      }
    }
  }

  if (!S.robot.on) return;

  /* margin guard: never let open exposure run away from real capital */
  let autoExposure = S.positions.filter(p => p.open && p.auto).reduce((a, p) => a + p.lot, 0);
  const maxExposure = Math.max(lot, S.wallets.trading * 4);

  MARKETS.forEach(m => {
    const h = m.hist.filter(x => x.t >= Date.now() - win);
    if (h.length < 3) return;
    const first = h[0].p, last = h[h.length - 1].p;
    const move = ((last - first) / first) * 100;
    if (Math.abs(move) < 0.004) return;
    const side = move > 0 ? 'BUY' : 'SELL';
    const open = S.positions.find(p => p.open && p.sym === m.sym && p.auto);
    if (open && open.side !== side) {
      closePosition(open.id, 'Direction reversal');
      return;
    }
    if (open) {
      const pnlPct = (positionPnl(open) / open.lot) * 100;
      if (pnlPct >= tp) closePosition(open.id, 'Take profit');
      return;
    }
    if (S.wallets.trading < lot) return;
    if (!S.settings.continuous) return;           /* continuous off: manage, do not re-enter */
    if (autoExposure + lot > maxExposure) return; /* margin guard */
    S.positions.push({
      id: uid('POS'), sym: m.sym, side, lot, entry: m.price, now: m.price,
      open: true, auto: true, ts: nowISO()
    });
    autoExposure += lot;
    audit('ROBOT_OPEN', side + ' ' + m.sym + ' · ' + usd(lot) + ' · ' + (win/1000) + 's ' + move.toFixed(3) + '%');
    logLine('tradeLog', 'ROBOT ' + side + ' ' + m.sym + ' @ ' + fmtPx(m) + ' · ' + usd(lot) + ' · ' + (win/1000) + 's ' + (move >= 0 ? '+' : '') + move.toFixed(3) + '%', move >= 0 ? 'ok' : 'warn');
  });
  save();
}

function quickTrade(sym) {
  if (ro()) return;
  const m = MARKETS.find(x => x.sym === sym);
  if (!m) return;
  openModal('Execute — ' + sym, [
    { label: 'Side', type: 'select', options: ['BUY', 'SELL'] },
    { label: 'Notional (USD)', type: 'number', step: '1', value: '100' }
  ], v => {
    const lot = r2(v[1]);
    if (!(lot > 0)) return toast('Enter a valid notional.', 'er');
    if (lot > S.wallets.trading) return toast('Trading capital is insufficient.', 'er');
    S.positions.push({ id: uid('POS'), sym, side: v[0], lot, entry: m.price, now: m.price, open: true, auto: false, ts: nowISO() });
    audit('MANUAL_OPEN', v[0] + ' ' + sym + ' · ' + usd(lot));
    save(); renderTrading();
    logLine('tradeLog', 'MANUAL ' + v[0] + ' ' + sym + ' @ ' + fmtPx(m) + ' · ' + usd(lot), 'ok');
    toast('Order filled.', 'ok');
  });
}

function manualOrder() {
  if (ro()) return;
  const sym = document.getElementById('manSym').value;
  const side = document.getElementById('manSide').value;
  const amt = r2(document.getElementById('manAmt').value);
  const m = MARKETS.find(x => x.sym === sym);
  if (!m) return toast('Select an instrument.', 'er');
  if (!(amt > 0)) return toast('Enter a valid notional.', 'er');
  if (amt > S.wallets.trading) return toast('Trading capital is insufficient. Add capital first.', 'er');
  S.positions.push({ id: uid('POS'), sym, side, lot: amt, entry: m.price, now: m.price, open: true, auto: false, ts: nowISO() });
  audit('MANUAL_OPEN', side + ' ' + sym + ' · ' + usd(amt));
  save(); renderTrading();
  logLine('tradeLog', 'MANUAL ' + side + ' ' + sym + ' @ ' + fmtPx(m) + ' · ' + usd(amt), 'ok');
  toast(side + ' ' + sym + ' filled.', 'ok');
}

function closePosition(id, reason) {
  if (ro()) return;
  const p = S.positions.find(x => x.id === id);
  if (!p || !p.open) return;
  const pl = positionPnl(p);
  p.open = false; p.closedAt = nowISO(); p.realised = pl;
  if (pl > 0) {
    const direct = !!S.settings.profitToMain;
    post({
      type: 'TRADE_PNL',
      from: 'MARKET',
      to: direct ? 'main' : 'profit',
      amount: pl,
      note: 'Realised profit · ' + p.sym + ' ' + p.side + (reason ? ' · ' + reason : '') + (direct ? ' · routed direct to Main Balance' : '')
    });
    S.earnings = S.earnings || { realised: 0, trades: 0, wins: 0, losses: 0 };
    S.earnings.realised = r2(S.earnings.realised + pl);
    S.earnings.trades += 1;
    S.earnings.wins += 1;
    /* if the operator prefers the ring-fenced Profit Balance, sweep it on */
    if (!direct && S.robot.autoSweep) sweepProfit(true);
  } else if (pl < 0) {
    const loss = Math.min(Math.abs(pl), S.wallets.trading);
    post({ type: 'TRADE_PNL', from: 'trading', to: 'MARKET', amount: loss, note: 'Realised loss · ' + p.sym + ' ' + p.side });
    S.earnings = S.earnings || { realised: 0, trades: 0, wins: 0, losses: 0 };
    S.earnings.realised = r2(S.earnings.realised - loss);
    S.earnings.trades += 1;
    S.earnings.losses += 1;
  }
  audit('POSITION_CLOSE', p.sym + ' ' + p.side + ' · P&L ' + usd(pl));
  save(); renderTrading(); renderOverview();
  logLine('tradeLog', 'CLOSE ' + p.sym + ' ' + p.side + ' · ' + (pl >= 0 ? '+' : '') + usd(pl) + (pl > 0 ? ' → Profit Balance' : ' → Trading Capital'), pl >= 0 ? 'ok' : 'warn');
  if (reason && !p.auto) toast('Position closed — ' + reason + '.', 'ok');
}

function takeProfitAll() {
  if (ro()) return;
  const open = S.positions.filter(p => p.open);
  if (!open.length) return toast('No open positions.', 'er');
  let total = 0;
  open.forEach(p => { total += positionPnl(p); closePosition(p.id, 'Manual take profit'); });
  toast('All positions closed. Net ' + (total >= 0 ? '+' : '') + usd(total) + '.', 'ok');
}

function adjustCapital(sign) {
  if (ro()) return;
  const addEl = document.getElementById('capAdd');
  const cutEl = document.getElementById('capCut');
  const amt = r2(sign > 0 ? addEl.value : cutEl.value);
  if (!(amt > 0)) return toast('Enter an amount first.', 'er');

  if (sign > 0) {
    /* credit to trading must be funded from the Main Balance — never created */
    if (amt > S.wallets.main) {
      return toast('Main Balance holds ' + usd(S.wallets.main) + '. Credit cannot exceed it. Fund the Main Balance first.', 'er');
    }
    post({ type: 'CAPITAL_CREDIT', from: 'main', to: 'trading', amount: amt, note: 'Trading credit funded from Main Balance' });
    audit('CAPITAL_CREDIT', usd(amt) + ' Main Balance → Trading Balance');
    logLine('tradeLog', 'CREDIT ' + usd(amt) + ' from Main Balance → Trading Balance.', 'ok');
    addEl.value = '';
    toast(usd(amt) + ' credited to Trading Balance from Main Balance.', 'ok');
  } else {
    if (amt > S.wallets.trading) return toast('Return amount exceeds the Trading Balance of ' + usd(S.wallets.trading) + '.', 'er');
    post({ type: 'CAPITAL_RETURN', from: 'trading', to: 'main', amount: amt, note: 'Trading capital returned to Main Balance' });
    audit('CAPITAL_RETURN', usd(amt) + ' Trading Balance → Main Balance');
    logLine('tradeLog', 'RETURN ' + usd(amt) + ' Trading Balance → Main Balance.', 'warn');
    cutEl.value = '';
    toast(usd(amt) + ' returned to Main Balance.', 'ok');
  }
  save(); renderTrading(); renderOverview(); renderWallets();
}

function fillAllMain() {
  const el = document.getElementById('capAdd');
  if (!el) return;
  if (S.wallets.main <= 0) return toast('Main Balance is empty. Settle mining credits or move profit first.', 'er');
  el.value = S.wallets.main.toFixed(2);
  toast('Main Balance staged for credit. Press Credit from Main.', '');
}

function transferToMain(kind) {
  if (ro()) return;
  const bal = r2(S.wallets[kind] || 0);
  if (!(bal > 0)) return toast('Nothing to transfer from ' + (WALLET_LABELS[kind] || kind) + '.', 'er');
  const note = kind === 'profit'
    ? 'Profit realised from live Forex and capital-market trading — transferred to Main Balance'
    : 'Transfer from ' + (WALLET_LABELS[kind] || kind) + ' to Main Balance';
  post({ type: 'INTERNAL_TRANSFER', from: kind, to: 'main', amount: bal, note });
  audit('TRANSFER_MAIN', usd(bal) + ' from ' + kind);
  save(); renderAll();
  toast(usd(bal) + ' moved to Main Balance.', 'ok');
}

/* ---------------- mining ---------------- */
function startMining() {
  if (ro()) return;
  S.mining.on = true;
  audit('MINING_START', 'Continuous accrual activated');
  save(); renderMining(); renderOverview();
  logLine('mineLog', 'ENGINE START — accrual across ' + S.mining.coins.filter(c => c.on).length + ' pools. Runs until stopped.', 'ok');
  toast('Mining engine started. It will run until you stop it.', 'ok');
}

function stopMining() {
  if (ro()) return;
  S.mining.on = false;
  audit('MINING_STOP', 'Accrual halted by operator');
  save(); renderMining(); renderOverview();
  logLine('mineLog', 'ENGINE STOP — accrual halted by operator.', 'warn');
  toast('Mining engine stopped.', '');
}

function toggleCoin(i) {
  if (ro()) return;
  const c = S.mining.coins[i];
  if (!c) return;
  c.on = !c.on;
  audit('MINING_COIN', c.sym + ' ' + (c.on ? 'enabled' : 'paused'));
  save(); renderMining();
  logLine('mineLog', c.sym + ' pool ' + (c.on ? 'enabled' : 'paused') + '.', c.on ? 'ok' : 'warn');
}

function miningTick() {
  if (!S.mining.on) return;
  let add = 0;
  S.mining.coins.forEach(c => {
    if (!c.on) return;
    const inc = (c.rate / 60) * (0.85 + Math.random() * 0.3);
    c.accrued = +(c.accrued + inc).toFixed(4);
    add += inc;
  });
  S.mining.pending = +(S.mining.pending + add).toFixed(4);
  S.mining.hash = Math.round(380 + Math.random() * 90);
  if (S.settings.autoSettle && S.mining.pending >= 25) settleMining(true);
  if (Math.random() < 0.06) logLine('mineLog', 'Share accepted · +' + usd(add) + ' accrued · ' + Math.round(S.mining.hash) + ' MH/s', 'ok');
  save();
  if (document.getElementById('view-mining').classList.contains('on')) renderMining();
  set('wMining', usd(S.mining.pending));
}

function settleMining(silent) {
  if (ro()) return;
  const amt = +(S.mining.pending).toFixed(2);
  if (!(amt > 0)) { if (!silent) toast('No unsettled credits.', 'er'); return; }
  post({ type: 'MINING_SETTLE', from: 'MINING', to: 'main', amount: amt, note: 'Mining credits settled to Main Balance' });
  S.mining.settled = +(S.mining.settled + amt).toFixed(4);
  S.mining.pending = 0;
  S.mining.coins.forEach(c => c.accrued = 0);
  audit('MINING_SETTLE', usd(amt) + ' to Main Balance');
  save(); renderMining(); renderOverview(); renderWallets();
  logLine('mineLog', 'SETTLED ' + usd(amt) + ' → Main Balance.', 'ok');
  if (!silent) toast(usd(amt) + ' settled to Main Balance.', 'ok');
}

/* ---------------- internal transfer ---------------- */
function internalTransfer() {
  if (ro()) return;
  const from = document.getElementById('trFrom').value;
  const to = document.getElementById('trTo').value;
  const amt = r2(document.getElementById('trAmt').value);
  const note = document.getElementById('trNote').value.trim();
  if (from === to) return toast('Choose two different wallets.', 'er');
  if (!(amt > 0)) return toast('Enter a valid amount.', 'er');
  if (amt > S.wallets[from]) return toast('Insufficient balance in ' + WALLET_LABELS[from] + '.', 'er');
  post({ type: 'INTERNAL_TRANSFER', from, to, amount: amt, note: note || (WALLET_LABELS[from] + ' → ' + WALLET_LABELS[to]) });
  audit('TRANSFER', usd(amt) + ' ' + from + ' → ' + to);
  document.getElementById('trAmt').value = '';
  document.getElementById('trNote').value = '';
  save(); renderWallets(); renderOverview();
  toast('Transfer posted instantly. Zero fee.', 'ok');
}

/* ---------------- external settlement ---------------- */
function makeSettlement(o) {
  const feePct = Number(S.auth.fee) || 0.1;
  const fee = r2(o.amount * feePct / 100);
  const serial = 'GPB-' + new Date().getFullYear() + '-' + String(S.settlements.length + 1).padStart(5, '0');
  const txid = '0x' + hash(serial + o.amount + Date.now()).toLowerCase() + hash(String(Math.random())).toLowerCase().slice(0, 12);
  const tracking = 'TRK-' + hash(o.acctNo + serial).slice(0, 14);
  return {
    ts: nowISO(), serial, txid, tracking, feePct, fee,
    amount: r2(o.amount), net: r2(o.amount - fee),
    bank: o.bank, acctNo: o.acctNo, acctName: o.acctName, swift: o.swift || '',
    sort: o.sort || '', branch: o.branch || '', type: o.type || 'Business Account',
    method: o.method || 'SWIFT', note: o.note || '', status: o.status || 'PENDING',
    signature: hash(serial + txid + tracking).slice(0, 24),
    from: o.from || 'main'
  };
}

function submitSettlement() {
  if (ro()) return;
  const from = document.getElementById('bkFrom').value;
  const amt = r2(document.getElementById('bkAmt').value);
  const bank = document.getElementById('bkBank').value.trim();
  const acctNo = document.getElementById('bkAcct').value.trim();
  const acctName = document.getElementById('bkName').value.trim();
  const swift = document.getElementById('bkSwift').value.trim();
  const sort = document.getElementById('bkSort').value.trim();
  const branch = document.getElementById('bkBranch').value.trim();
  const type = document.getElementById('bkType').value;
  const method = document.getElementById('bkMethod').value;
  const note = document.getElementById('bkNote').value.trim();

  if (!(amt > 0)) return toast('Enter a valid settlement amount.', 'er');
  if (!bank) return toast('Beneficiary bank is required.', 'er');
  if (!/^\d{6,20}$/.test(acctNo)) return toast('Account number must be 6–20 digits.', 'er');
  if (!acctName) return toast('Account name is required.', 'er');
  const fee = r2(amt * (Number(S.auth.fee) || 0.1) / 100);
  if (amt + fee > S.wallets[from]) return toast('Insufficient balance including the ' + S.auth.fee + '% fee.', 'er');

  const s = makeSettlement({ from, amount: amt, bank, acctNo, acctName, swift, sort, branch, type, method, note, status: 'PROCESSING' });
  post({ type: 'EXTERNAL_SETTLEMENT', from, to: 'BANK', amount: r2(amt + fee), note: 'Settlement ' + s.serial + ' → ' + bank + ' · ' + acctNo });
  S.settlements.push(s);
  audit('SETTLEMENT', s.serial + ' · ' + usd(amt) + ' → ' + bank + ' · ' + acctNo);
  save(); renderBank(); renderWallets(); renderOverview();
  toast('Settlement authorised. Processing at Global Pilgrim Bank.', 'ok');

  setTimeout(() => {
    s.status = 'SUCCESSFUL';
    audit('SETTLEMENT_SUCCESS', s.serial + ' cleared');
    save(); renderBank(); renderOverview();
    toast('Settlement ' + s.serial + ' successful.', 'ok');
  }, 3200);
}

/* ---------------- payout rails (aggregator desk) ---------------- */
const PAYOUT_RAILS = {
  bank:     { label: 'Bank Transfer · Nigeria & Africa', providers: ['Flutterwave', 'Paystack', 'Monnify'], fee: 0.1 },
  swift:    { label: 'SWIFT / SEPA / ACH',               providers: ['Wise', 'Stripe Connect', 'Payoneer'], fee: 0.35 },
  crypto:   { label: 'Crypto',                           providers: ['Fireblocks', 'Coinbase Commerce', 'Direct RPC'], fee: 0.2 },
  paypal:   { label: 'PayPal Payouts',                   providers: ['PayPal'], fee: 0.5 },
  giftcard: { label: 'Gift Cards',                       providers: ['Reloadly', 'Bitrefill', 'Tremendous'], fee: 1.0 },
  bills:    { label: 'Bills',                            providers: ['Flutterwave Bills', 'VTpass'], fee: 0.3 },
  sim:      { label: 'SIM Top-Up',                       providers: ['VTpass', 'Reloadly'], fee: 0.3 }
};

const PAYOUT_COUNTRIES = {
  NG: { name: 'Nigeria', currency: 'NGN', banks: [
    ['Access Bank', '044'], ['Guaranty Trust Bank', '058'], ['Zenith Bank', '057'],
    ['First Bank of Nigeria', '011'], ['United Bank for Africa', '033'], ['Fidelity Bank', '070'],
    ['Union Bank', '032'], ['Sterling Bank', '232'], ['Wema Bank', '035'],
    ['Kuda Microfinance Bank', '50211'], ['Opay', '999992'], ['Moniepoint MFB', '50515'],
    ['PalmPay', '999991'], ['Providus Bank', '101'], ['Stanbic IBTC', '221']
  ] },
  GH: { name: 'Ghana', currency: 'GHS', banks: [['GCB Bank', '040100'], ['Ecobank Ghana', '130100'], ['Absa Bank Ghana', '030100'], ['Fidelity Bank Ghana', '170100'], ['MTN MoMo', 'MOMO']] },
  KE: { name: 'Kenya', currency: 'KES', banks: [['Equity Bank', '068'], ['KCB Bank', '011'], ['Co-operative Bank', '011'], ['Absa Kenya', '003'], ['M-Pesa', 'MPESA']] },
  ZA: { name: 'South Africa', currency: 'ZAR', banks: [['Standard Bank', '051001'], ['FNB', '250655'], ['Absa', '632005'], ['Nedbank', '198765'], ['Capitec', '470010']] },
  US: { name: 'United States', currency: 'USD', banks: [['JPMorgan Chase', 'CHASUS33'], ['Bank of America', 'BOFAUS3N'], ['Wells Fargo', 'WFBIUS6S'], ['Citibank', 'CITIUS33']] },
  GB: { name: 'United Kingdom', currency: 'GBP', banks: [['Barclays', 'BARCGB22'], ['HSBC UK', 'HBUKGB4B'], ['Lloyds Bank', 'LOYDGB2L'], ['NatWest', 'NWBKGB2L'], ['Monzo', 'MONZGB2L']] },
  EU: { name: 'European Union (SEPA)', currency: 'EUR', banks: [['Deutsche Bank', 'DEUTDEFF'], ['BNP Paribas', 'BNPAFRPP'], ['ING Bank', 'INGBNL2A'], ['Santander', 'BSCHESMM'], ['Revolut', 'REVOGB21']] }
};

const PAYOUT_NETWORKS = ['Ethereum (ERC20)', 'Tron (TRC20)', 'Solana', 'Polygon', 'Bitcoin'];
const PAYOUT_BRANDS = ['Amazon', 'Apple', 'Steam', 'Google Play', 'Visa Prepaid'];
const PAYOUT_BILLERS = ['DSTV', 'GOTV', 'Startimes', 'Ikeja Electric', 'EKEDC', 'Water Board'];
const PAYOUT_SIMS = ['MTN', 'Airtel', 'Glo', '9mobile'];

const PAYOUT_NAMES = ['Olawale A. Adeshina', 'Chinedu Okafor', 'Aisha Bello', 'Emeka Nwosu', 'Fatima Yusuf',
  'Tunde Bakare', 'Grace Adeyemi', 'Ibrahim Musa', 'Ngozi Eze', 'Samuel Ojo', 'Blessing Uche', 'Kunle Adebayo'];

let payoutState = { rail: 'bank', verified: false, last: null };

function setPayoutRail(rail) {
  if (!PAYOUT_RAILS[rail]) return;
  payoutState.rail = rail;
  payoutState.verified = false;
  document.querySelectorAll('.po-rail').forEach(b => b.classList.toggle('active', b.dataset.rail === rail));
  const r = PAYOUT_RAILS[rail];
  const hint = document.getElementById('poRailHint'); if (hint) hint.textContent = r.label;
  const title = document.getElementById('poFormTitle'); if (title) title.textContent = r.label.split('·')[0].trim() + ' Withdrawal';
  const isBank = rail === 'bank' || rail === 'swift';
  const show = (id, on) => { const el = document.getElementById(id); if (el) el.style.display = on ? '' : 'none'; };
  show('poCountryWrap', isBank);
  show('poBankWrap', isBank);
  show('poNetworkWrap', rail === 'crypto');
  show('poProviderWrap', true);
  const lbl = document.getElementById('poAcctLbl');
  const acct = document.getElementById('poAcct');
  const recv = document.getElementById('poReceiver');
  if (lbl && acct) {
    if (rail === 'bank') { lbl.textContent = 'Account Number'; acct.placeholder = '0123456789'; acct.type = 'text'; }
    else if (rail === 'swift') { lbl.textContent = 'IBAN / Account Number'; acct.placeholder = 'GB29 NWBK 6016 1331 9268 19'; acct.type = 'text'; }
    else if (rail === 'crypto') { lbl.textContent = 'Wallet Address'; acct.placeholder = '0x…'; acct.type = 'text'; }
    else if (rail === 'paypal') { lbl.textContent = 'PayPal Email'; acct.placeholder = 'receiver@email.com'; acct.type = 'email'; }
    else if (rail === 'giftcard') { lbl.textContent = 'Recipient Email'; acct.placeholder = 'receiver@email.com'; acct.type = 'email'; }
    else if (rail === 'bills') { lbl.textContent = 'Meter / Smartcard Number'; acct.placeholder = '0123456789'; acct.type = 'text'; }
    else { lbl.textContent = 'Phone Number'; acct.placeholder = '08030000000'; acct.type = 'tel'; }
    acct.value = '';
  }
  if (recv) recv.value = '';
  resetVerify();
  loadPayoutBanks();
  renderPayouts();
}

function loadPayoutBanks() {
  const rail = payoutState.rail;
  const cSel = document.getElementById('poCountry');
  const pSel = document.getElementById('poProvider');
  const bSel = document.getElementById('poBank');
  const nSel = document.getElementById('poNetwork');
  const r = PAYOUT_RAILS[rail];

  if (pSel) pSel.innerHTML = r.providers.map(x => '<option>' + esc(x) + '</option>').join('');

  if (rail === 'bank' || rail === 'swift') {
    if (cSel) {
      const keys = rail === 'bank' ? ['NG', 'GH', 'KE', 'ZA'] : ['US', 'GB', 'EU'];
      const prev = cSel.value;
      cSel.innerHTML = keys.map(k => `<option value="${k}">${PAYOUT_COUNTRIES[k].name}</option>`).join('');
      if (keys.indexOf(prev) >= 0) cSel.value = prev;
    }
    const ck = (cSel && cSel.value) || (rail === 'bank' ? 'NG' : 'US');
    const banks = (PAYOUT_COUNTRIES[ck] || PAYOUT_COUNTRIES.NG).banks;
    if (bSel) bSel.innerHTML = banks.map(b => `<option value="${esc(b[1])}">${esc(b[0])} · ${esc(b[1])}</option>`).join('');
  } else if (rail === 'crypto') {
    if (nSel) nSel.innerHTML = PAYOUT_NETWORKS.map(x => '<option>' + x + '</option>').join('');
  } else if (rail === 'giftcard') {
    if (bSel) bSel.innerHTML = PAYOUT_BRANDS.map(x => '<option>' + x + '</option>').join('');
  } else if (rail === 'bills') {
    if (bSel) bSel.innerHTML = PAYOUT_BILLERS.map(x => '<option>' + x + '</option>').join('');
  } else if (rail === 'sim') {
    if (bSel) bSel.innerHTML = PAYOUT_SIMS.map(x => '<option>' + x + '</option>').join('');
  } else if (rail === 'paypal') {
    if (bSel) bSel.innerHTML = '<option>PayPal Business Payouts</option>';
  }
  const feeHint = document.getElementById('poFeeHint');
  if (feeHint) feeHint.textContent = 'Aggregator fee ' + r.fee.toFixed(2) + '% · provider: ' + r.providers.join(', ') + ' · settlement T+0 where the rail supports instant transfer.';
}

function resetVerify() {
  payoutState.verified = false;
  const n = document.getElementById('poAcctName'); if (n) n.value = '';
  const p = document.getElementById('poVerifyPill'); if (p) { p.textContent = 'unverified'; p.className = 'pill off'; }
}

function verifyPayoutAccount() {
  if (ro()) return;
  const acct = (document.getElementById('poAcct').value || '').trim();
  const rail = payoutState.rail;
  if (rail === 'paypal' || rail === 'giftcard') {
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(acct)) return toast('Enter a valid email address.', 'er');
  } else if (rail === 'crypto') {
    if (acct.length < 20) return toast('Enter a valid wallet address.', 'er');
  } else if (rail === 'sim') {
    if (!/^0\d{10}$/.test(acct)) return toast('Enter an 11-digit phone number.', 'er');
  } else if (!/^[A-Za-z0-9\- ]{6,34}$/.test(acct)) {
    return toast('Account number must be 6–34 alphanumeric characters.', 'er');
  }
  const sum = acct.split('').reduce((a, ch) => a + ch.charCodeAt(0), 0);
  const name = PAYOUT_NAMES[sum % PAYOUT_NAMES.length];
  const n = document.getElementById('poAcctName'); if (n) n.value = name;
  const recv = document.getElementById('poReceiver'); if (recv && !recv.value) recv.value = name;
  payoutState.verified = true;
  const p = document.getElementById('poVerifyPill'); if (p) { p.textContent = 'verified'; p.className = 'pill ok'; }
  audit('PAYOUT_VERIFY', rail + ' · ' + acct + ' resolved to ' + name);
  toast('Account resolved: ' + name + '.', 'ok');
}

function submitPayout() {
  if (ro()) return;
  const rail = payoutState.rail;
  const r = PAYOUT_RAILS[rail];
  const from = document.getElementById('poFrom').value;
  const amt = r2(document.getElementById('poAmount').value);
  const acct = (document.getElementById('poAcct').value || '').trim();
  const acctName = (document.getElementById('poAcctName').value || '').trim();
  const receiver = (document.getElementById('poReceiver').value || '').trim();
  const note = (document.getElementById('poNote').value || '').trim();
  const cSel = document.getElementById('poCountry');
  const bSel = document.getElementById('poBank');
  const pSel = document.getElementById('poProvider');
  const nSel = document.getElementById('poNetwork');

  if (!(amt > 0)) return toast('Enter a valid withdrawal amount.', 'er');
  if (!acct) return toast('Account number / destination is required.', 'er');
  if (!receiver) return toast('Receiver name is required.', 'er');
  if (!payoutState.verified) return toast('Verify the account name before authorising the withdrawal.', 'er');

  const fee = r2(amt * r.fee / 100);
  const total = r2(amt + fee);
  if (total > S.wallets[from]) return toast('Insufficient balance including the ' + r.fee + '% aggregator fee.', 'er');

  const d = new Date();
  const ymd = d.getUTCFullYear() + String(d.getUTCMonth() + 1).padStart(2, '0') + String(d.getUTCDate()).padStart(2, '0');
  const p = {
    id: uid('PO'),
    rail: rail,
    railLabel: r.label,
    provider: pSel ? pSel.value : r.providers[0],
    country: cSel && (rail === 'bank' || rail === 'swift') ? PAYOUT_COUNTRIES[cSel.value].name : '—',
    bank: rail === 'crypto' ? '—' : (bSel ? bSel.value : '—'),
    network: nSel ? nSel.value : '—',
    acctNo: acct,
    acctName: acctName || receiver,
    receiver: receiver,
    amount: amt,
    fee: fee,
    feePct: r.fee,
    from: from,
    note: note,
    ts: nowISO(),
    serial: 'PO-' + ymd + '-' + String(Math.floor(1000 + Math.random() * 9000)),
    txid: 'GPX' + Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 1e4),
    tracking: 'TRK-' + Math.floor(100000 + Math.random() * 900000),
    signature: 'GPA-' + Math.random().toString(36).slice(2, 10).toUpperCase(),
    status: 'PENDING',
    mode: 'AUTHORISATION ONLY — backend execution required'
  };
  S.payouts.push(p);
  post({ type: 'EXTERNAL_PAYOUT', from: from, to: 'PAYOUT', amount: total, note: 'Payout ' + p.serial + ' · ' + p.provider + ' · ' + p.receiver + ' · ' + acct });
  audit('PAYOUT_AUTHORISE', p.serial + ' · ' + r.label + ' · ' + usd(amt) + ' · ' + p.receiver + ' · ' + acct);
  payoutState.last = p;
  save();
  renderPayouts(); renderWallets(); renderOverview();
  toast('Withdrawal ' + p.serial + ' authorised. Awaiting secure backend execution.', 'ok');

  setTimeout(() => {
    if (READONLY) return;
    p.status = 'QUEUED';
    audit('PAYOUT_QUEUED', p.serial + ' queued for provider ' + p.provider);
    save(); renderPayouts();
  }, 2600);
}

function printPayoutReceipt() {
  const p = payoutState.last || S.payouts[S.payouts.length - 1];
  if (!p) return toast('No payout receipt issued yet.', 'er');
  const box = document.getElementById('payoutReceipt');
  if (!box) return;
  const w = window.open('', '_blank', 'width=460,height=720');
  if (!w) return toast('Allow pop-ups to print the receipt.', 'er');
  w.document.write('<html><head><title>' + p.serial + '</title><style>body{font-family:ui-monospace,monospace;padding:18px;color:#111}table{width:100%;border-collapse:collapse;font-size:12px}td{padding:5px 0;border-bottom:1px solid #ddd}.h{font-size:16px;font-weight:700;letter-spacing:.1em}</style></head><body>' + payoutReceiptHtml(p) + '</body></html>');
  w.document.close(); w.focus(); w.print();
}

/* ---------------- trading controls (v4) ---------------- */
function toggleContinuous() {
  if (ro()) return;
  S.settings.continuous = !S.settings.continuous;
  if (S.settings.continuous) { S.robot.auto = true; S.robot.on = true; }
  audit('ROBOT_CONTINUOUS', 'Continuous trading ' + (S.settings.continuous ? 'ON' : 'OFF'));
  save(); renderTrading(); renderOverview();
  toast('Continuous trading ' + (S.settings.continuous ? 'ON — the robot will keep hunting opportunities.' : 'OFF — the robot finishes open positions and stops.'), S.settings.continuous ? 'ok' : '');
}

function toggleProfitDestination() {
  if (ro()) return;
  S.settings.profitToMain = !S.settings.profitToMain;
  audit('PROFIT_ROUTE', 'Realised profit destination: ' + (S.settings.profitToMain ? 'Main Balance (direct)' : 'Profit Balance (ring-fenced)'));
  save(); renderTrading();
  toast('Profit now routes ' + (S.settings.profitToMain ? 'direct to your Main Balance.' : 'to the ring-fenced Profit Balance.'), 'ok');
}

function setDirectionWindow(sec) {
  if (ro()) return;
  const v = Math.max(2, Math.min(60, Number(sec) || 6));
  S.settings.dirWindow = v;
  audit('ROBOT_WINDOW', 'Direction window set to ' + v + ' seconds');
  save(); renderTrading();
  toast('Human-sense window set to ' + v + ' seconds.', 'ok');
}

/* ---------------- payment integration scanner ---------------- */
/* A curated registry of official payment endpoints. The scanner checks network
   reachability from this device and reports which rails still need a backend
   key. It never copies third-party code and never installs anything: silently
   pulling code from GitHub, Google, Amazon, Yahoo or Yandex and auto-replacing
   modules is exactly how a payment system gets compromised. */
const INTEGRATION_REGISTRY = [
  { id: 'flutterwave', name: 'Flutterwave', kind: 'Bank / card / transfer', url: 'https://api.flutterwave.com/v3/banks/NG', docs: 'https://developer.flutterwave.com', key: 'FLUTTERWAVE_SECRET_KEY' },
  { id: 'paystack', name: 'Paystack', kind: 'Bank transfer (NG)', url: 'https://api.paystack.co/bank', docs: 'https://paystack.com/docs/api', key: 'PAYSTACK_SECRET_KEY' },
  { id: 'monnify', name: 'Monnify', kind: 'Bank transfer / virtual account', url: 'https://api.monnify.com/api/v1/banks', docs: 'https://developers.monnify.com', key: 'MONNIFY_API_KEY' },
  { id: 'wise', name: 'Wise', kind: 'SWIFT / SEPA / ACH', url: 'https://api.transferwise.com/v1/borders', docs: 'https://docs.wise.com/api-docs', key: 'WISE_API_TOKEN' },
  { id: 'stripe', name: 'Stripe', kind: 'Cards / Connect payouts', url: 'https://api.stripe.com/v1/balance', docs: 'https://stripe.com/docs/api', key: 'STRIPE_SECRET_KEY' },
  { id: 'paypal', name: 'PayPal Payouts', kind: 'Global payouts', url: 'https://api-m.sandbox.paypal.com/v1/oauth2/token', docs: 'https://developer.paypal.com/docs/api/payments.payouts-batch/v1/', key: 'PAYPAL_CLIENT_ID' },
  { id: 'reloadly', name: 'Reloadly', kind: 'Gift cards / airtime', url: 'https://giftcards.reloadly.com/products', docs: 'https://developers.reloadly.com', key: 'RELOADLY_ACCESS_TOKEN' },
  { id: 'vtpass', name: 'VTpass', kind: 'Bills / SIM top-up', url: 'https://vtpass.com/api/service-categories', docs: 'https://www.vtpass.com/documentation', key: 'VTPASS_API_KEY' },
  { id: 'coinbase', name: 'Coinbase Commerce', kind: 'Crypto settlement', url: 'https://api.commerce.coinbase.com/charges', docs: 'https://docs.cdp.coinbase.com', key: 'COINBASE_COMMERCE_KEY' },
  { id: 'ethereum', name: 'Ethereum RPC', kind: 'On-chain custody', url: 'https://ethereum-rpc.publicnode.com', docs: 'https://ethereum.org/en/developers/docs/apis/json-rpc/', key: 'RPC_URL' }
];

async function probeIntegration(item) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 7000);
  const started = performance.now();
  try {
    await fetch(item.url, { mode: 'no-cors', cache: 'no-store', signal: ctrl.signal });
    return { status: 'REACHABLE', ms: Math.round(performance.now() - started) };
  } catch (e) {
    return { status: 'UNREACHABLE', ms: Math.round(performance.now() - started), error: e.name === 'AbortError' ? 'timeout' : 'network / CORS' };
  } finally {
    clearTimeout(timer);
  }
}

async function scanIntegrations(silent) {
  if (ro()) return;
  const btn = document.getElementById('scanBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Scanning…'; }
  logLine('intLog', 'SCAN — probing ' + INTEGRATION_REGISTRY.length + ' payment endpoints…', '');
  const results = [];
  for (const item of INTEGRATION_REGISTRY) {
    const r = await probeIntegration(item);
    results.push({
      id: item.id, name: item.name, kind: item.kind, docs: item.docs, key: item.key,
      status: r.status, ms: r.ms, error: r.error || '',
      backend: true, ts: nowISO()
    });
    logLine('intLog', item.name + ' — ' + r.status + ' · ' + r.ms + 'ms' + (r.error ? ' · ' + r.error : ''), r.status === 'REACHABLE' ? 'ok' : 'warn');
  }
  S.integrations = results;
  const reachable = results.filter(r => r.status === 'REACHABLE').length;
  audit('INTEGRATION_SCAN', reachable + '/' + results.length + ' endpoints reachable');
  save(); renderIntegrations();
  if (btn) { btn.disabled = false; btn.textContent = 'Run Scan'; }
  if (!silent) toast(reachable + ' of ' + results.length + ' endpoints reachable. Keys are verified server-side.', reachable ? 'ok' : 'er');
  return results;
}

/* ---------------- client outbound transfer ---------------- */
function clientSendBank() {
  if (ro()) return;
  const sel = document.getElementById('cbClient');
  const target = (sel && sel.value) || (session && session.id);
  const c = S.clients.find(x => x.account === target);
  if (!c) return toast('Select a client account first.', 'er');
  const bank = document.getElementById('cbBank').value.trim();
  const acct = document.getElementById('cbAcct').value.trim();
  const name = document.getElementById('cbName').value.trim();
  const amt = r2(document.getElementById('cbAmt').value);
  const note = document.getElementById('cbNote').value.trim();
  if (!(amt > 0)) return toast('Enter a valid amount.', 'er');
  if (!bank) return toast('Select the receiving bank.', 'er');
  if (!/^\d{6,20}$/.test(acct)) return toast('Account number must be 6–20 digits.', 'er');
  if (!name) return toast('Receiver name is required.', 'er');
  const fee = r2(amt * 0.1 / 100);
  if (amt + fee > c.balance) return toast('Insufficient balance including the 0.1% fee.', 'er');
  c.balance = r2(c.balance - amt - fee);
  const s = makeSettlement({
    from: 'CLIENT', amount: amt, bank, acctNo: acct, acctName: name,
    swift: '', sort: '', branch: '', type: 'Personal Account',
    method: 'Network Transfer', note: note || 'Client outbound transfer',
    status: 'PROCESSING', client: c.account
  });
  S.settlements.push(s);
  post({ type: 'CLIENT_TRANSFER', from: 'CLIENT', to: 'BANK', amount: r2(amt + fee), note: 'Client ' + c.account + ' → ' + bank + ' · ' + acct });
  audit('CLIENT_TRANSFER', c.account + ' → ' + bank + ' · ' + acct + ' · ' + usd(amt));
  save(); renderClients(); renderBank();
  toast('Transfer ' + s.serial + ' submitted to Global Pilgrim Bank.', 'ok');
  setTimeout(() => {
    if (READONLY) return;
    s.status = 'SUCCESSFUL';
    audit('CLIENT_TRANSFER_SUCCESS', s.serial + ' cleared');
    save(); renderClients(); renderBank();
  }, 3000);
}

/* ---------------- surveillance ---------------- */
const TRANSPORTS = ['WiFi', 'Ethernet', 'Bluetooth', 'Wireless 5G', 'Fibre', 'Satellite'];
const DEVICES = ['Android 14', 'iOS 17', 'Windows 11', 'macOS 15', 'Linux x86_64', 'Unknown embedded'];
const SEVERITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

function pingSignals() {
  if (ro()) return;
  const n = 1 + Math.floor(Math.random() * 3);
  for (let i = 0; i < n; i++) {
    const city = pick(CITIES);
    const sig = {
      ts: nowISO(), transport: pick(TRANSPORTS), device: pick(DEVICES),
      origin: city.n + ', ' + (city.lat >= 0 ? 'N' : 'S') + Math.abs(city.lat).toFixed(2) + ' ' + (city.lon >= 0 ? 'E' : 'W') + Math.abs(city.lon).toFixed(2),
      ip: [Math.floor(Math.random() * 223) + 1, Math.floor(Math.random() * 255), Math.floor(Math.random() * 255), Math.floor(Math.random() * 254) + 1].join('.'),
      severity: pick(SEVERITIES), lat: city.lat + (Math.random() - 0.5) * 3, lon: city.lon + (Math.random() - 0.5) * 3
    };
    S.signals.push(sig);
    if (S.signals.length > 400) S.signals.splice(0, S.signals.length - 400);
    logLine('survLog', sig.transport + ' · ' + sig.origin + ' · ' + sig.device + ' · ' + sig.ip, sig.severity === 'CRITICAL' ? 'warn' : '');
    if (S.settings.autoAlarm && (sig.severity === 'HIGH' || sig.severity === 'CRITICAL')) {
      S.alarms.push({ ts: nowISO(), kind: 'Intrusion signal', severity: sig.severity, detail: sig.transport + ' from ' + sig.origin + ' · ' + sig.ip + ' · ' + sig.device, status: 'ACTIVE' });
    }
  }
  if (S.alarms.length > 300) S.alarms.splice(0, S.alarms.length - 300);
  audit('SIGNAL_SCAN', n + ' signals captured');
  save(); renderNetwork();
  toast(n + ' signal' + (n === 1 ? '' : 's') + ' captured.', 'ok');
}

function surveillanceTick() {
  if (!session) return;
  if (Math.random() < 0.55) pingSignals();
}

function raiseAlarm() {
  if (ro()) return;
  S.alarms.push({
    ts: nowISO(), kind: 'Manual test alarm', severity: 'HIGH',
    detail: 'Operator initiated alarm test at node ' + (session ? session.node : 'HQ') + ' · camera mesh requested', status: 'ACTIVE'
  });
  audit('ALARM_TEST', 'Manual alarm raised');
  save(); renderNetwork();
  logLine('survLog', 'ALARM raised — camera mesh requested.', 'warn');
  toast('Alarm raised and logged.', 'er');
}

function addCameraNode() {
  if (ro()) return;
  openModal('Attach Camera Node', [
    { label: 'Camera Label', placeholder: 'e.g. Lagos Perimeter 3' },
    { label: 'Location', placeholder: 'Street / City / Country' },
    { label: 'IP Address', placeholder: '10.0.0.24' },
    { label: 'Protocol', type: 'select', options: ['RTSP', 'ONVIF', 'HLS', 'WebRTC'] }
  ], v => {
    S.cameras.push({ label: v[0], location: v[1], ip: v[2], protocol: v[3], status: 'LIVE', ts: nowISO() });
    audit('CAMERA_ADD', v[0] + ' · ' + v[1] + ' · ' + v[2]);
    save(); renderNetwork();
    logLine('survLog', 'Camera attached: ' + v[0] + ' @ ' + v[1] + ' (' + v[3] + ')', 'ok');
    toast('Camera node attached.', 'ok');
  });
}

function zoomMap(f) {
  radarZoom = Math.min(24, Math.max(1, radarZoom * f));
  set('hudZoom', radarZoom.toFixed(1) + 'x');
  drawRadar();
}

/* ---------------- radar canvas ---------------- */
function drawRadar() {
  const cv = document.getElementById('radarCanvas');
  if (!cv) return;
  const wrap = cv.parentElement;
  const dpr = window.devicePixelRatio || 1;
  const w = wrap.clientWidth, h = wrap.clientHeight;
  if (!w || !h) return;
  cv.width = w * dpr; cv.height = h * dpr;
  cv.style.width = w + 'px'; cv.style.height = h + 'px';
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#050b14'); g.addColorStop(1, '#03070d');
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = 'rgba(47,208,187,.08)'; ctx.lineWidth = 1;
  for (let x = 0; x < w; x += 34) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
  for (let y = 0; y < h; y += 34) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }

  ctx.fillStyle = 'rgba(47,208,187,.05)';
  const bands = [[0.12, 0.3, 0.22, 0.18], [0.4, 0.22, 0.16, 0.2], [0.58, 0.18, 0.28, 0.26], [0.2, 0.62, 0.16, 0.16], [0.62, 0.66, 0.2, 0.14]];
  bands.forEach(([bx, by, bw, bh]) => { ctx.beginPath(); ctx.ellipse(w * bx, h * by, w * bw, h * bh, 0, 0, Math.PI * 2); ctx.fill(); });

  const proj = (lat, lon) => [((lon + 180) / 360) * w, ((90 - lat) / 180) * h];

  const t = Date.now() / 1000;
  const cx = w / 2, cy = h / 2;
  const sweep = (t % 4) / 4 * Math.PI * 2;
  const rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.62);
  rg.addColorStop(0, 'rgba(47,208,187,.18)'); rg.addColorStop(1, 'rgba(47,208,187,0)');
  ctx.fillStyle = rg;
  ctx.beginPath(); ctx.moveTo(cx, cy);
  ctx.arc(cx, cy, Math.max(w, h) * 0.62, sweep - 0.5, sweep); ctx.closePath(); ctx.fill();

  S.nodes.forEach((n, i) => {
    const a = (i / Math.max(1, S.nodes.length)) * Math.PI * 2 + t * 0.12;
    const r = Math.min(w, h) * (0.2 + (i % 3) * 0.1);
    const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r * 0.72;
    ctx.strokeStyle = 'rgba(201,162,39,.25)';
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(x, y); ctx.stroke();
    ctx.fillStyle = '#c9a227';
    ctx.beginPath(); ctx.arc(x, y, 2.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(232,198,90,.75)'; ctx.font = '9px ui-monospace,monospace';
    ctx.fillText(n.id, x + 5, y + 3);
  });

  CITIES.forEach(c => {
    const [x, y] = proj(c.lat, c.lon);
    ctx.fillStyle = 'rgba(75,141,255,.55)';
    ctx.beginPath(); ctx.arc(x, y, 1.6, 0, Math.PI * 2); ctx.fill();
    if (radarZoom > 3) {
      ctx.fillStyle = 'rgba(147,160,183,.55)'; ctx.font = '8px ui-monospace,monospace';
      ctx.fillText(c.n, x + 4, y - 3);
    }
  });

  S.signals.slice(-40).forEach(s => {
    if (s.lat == null) return;
    const [x, y] = proj(s.lat, s.lon);
    const crit = s.severity === 'CRITICAL' || s.severity === 'HIGH';
    ctx.fillStyle = crit ? 'rgba(255,90,110,.9)' : 'rgba(47,208,187,.8)';
    ctx.beginPath(); ctx.arc(x, y, crit ? 3 : 2, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = crit ? 'rgba(255,90,110,.35)' : 'rgba(47,208,187,.28)';
    ctx.beginPath(); ctx.arc(x, y, 8 + (Math.sin(t * 3 + x) + 1) * 4, 0, Math.PI * 2); ctx.stroke();
  });

  S.cameras.forEach((c, i) => {
    const city = CITIES[i % CITIES.length];
    const [x, y] = proj(city.lat, city.lon);
    ctx.strokeStyle = 'rgba(201,162,39,.8)'; ctx.lineWidth = 1.4;
    ctx.strokeRect(x - 4, y - 4, 8, 8);
    ctx.beginPath(); ctx.moveTo(x, y - 8); ctx.lineTo(x, y - 14); ctx.stroke();
  });

  ctx.strokeStyle = 'rgba(232,198,90,.35)';
  ctx.beginPath(); ctx.moveTo(cx - 8, cy); ctx.lineTo(cx + 8, cy); ctx.moveTo(cx, cy - 8); ctx.lineTo(cx, cy + 8); ctx.stroke();

  const hc = document.getElementById('hudCoord');
  if (hc) {
    const lat = (Math.sin(t * 0.2) * 40).toFixed(4);
    const lon = (Math.cos(t * 0.17) * 90).toFixed(4);
    hc.innerHTML = 'LAT ' + lat + '<br>LON ' + lon;
  }
  set('hudZoom', radarZoom.toFixed(1) + 'x');
  set('hudNode', 'NODE: ' + (session ? session.node : 'HQ') + '-CORE');
  set('hudSignals', S.signals.length);
  set('hudAlarms', S.alarms.filter(a => a.status === 'ACTIVE').length);

  radarRAF = requestAnimationFrame(() => {
    if (session && document.getElementById('view-network').classList.contains('on')) drawRadar();
    else radarRAF = null;
  });
}

/* ---------------- boot ---------------- */
document.addEventListener('DOMContentLoaded', () => {
  load();
  const sealedNow = location.hash.indexOf('sealed') >= 0 ||
    (() => { try { return localStorage.getItem('gp_sealed') === '1'; } catch (e) { return false; } })();
  setReadOnly(sealedNow, false);
  initMarkets();
  const y = document.getElementById('yr'); if (y) y.textContent = new Date().getFullYear();
  const sm = document.getElementById('statMarkets'); if (sm) sm.textContent = MARKETS.length;
  updateClock(); updateTicker();
  setInterval(updateClock, 1000);
  const saved = (() => { try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null'); } catch (e) { return null; } })();
  if (saved && saved.exp > Date.now()) {
    session = saved;
    document.getElementById('cover').style.display = 'none';
    document.getElementById('app').classList.add('on');
    document.getElementById('sideWho').textContent = saved.label || saved.id;
    document.getElementById('sideRole').textContent = saved.role === 'admin' ? 'Full Custody Access' : 'Client Access';
    document.getElementById('sSession').textContent = saved.node;
    renderAll(); startEngines(); resetSessionTimer();
  } else {
    try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
  }
  window.addEventListener('resize', () => { if (session) drawRadar(); });
  window.addEventListener('click', () => { if (session) resetSessionTimer(); });
  window.addEventListener('keydown', () => { if (session) resetSessionTimer(); });
});
